<div class="header" style="background-color: white">
    <img src="img/logo.png" width="200" height="200px" alt="Logo">
    <nav class="nav_style" >
        <a href="index.php" class="nav_buttons"><i></i>Home</a>
        <a href="trending.html" class="nav_buttons"><i></i>Candidates</a>
        <a href="trending.html" class="nav_buttons"><i></i>Municpalities</a>
        <a href="new_releases.html" class="nav_buttons"><i></i>Results</a>
        <a href="top_rated.html" class="nav_buttons"><i></i>How To</a>
        <a href="featured.html" class="nav_buttons"><i></i>About</a>
        <?php
            session_start();
            if (isset($_SESSION["password"]) && $_SESSION["loggedin"] === true) {
                echo '<a href="update.php" class="nav_buttons"><i></i>Update Address</a>';
                echo '<a href="voter_logout.php" class="nav_buttons"><i></i>Logout</a>';
            }
        ?>
    </nav>
</div>

