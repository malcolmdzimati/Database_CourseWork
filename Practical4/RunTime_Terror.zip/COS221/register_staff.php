<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/register_staff_style.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/footer.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">
    <script src="js/staff_reg_validation.js"></script>
</head>
<body>
<div class="loader"><img src="img/loader.gif" alt="Sharingan"></div>
<?php include "header.php"; ?>
<div class="wrapper" style="background-color: black; padding-bottom: 100px; padding-top: 100px;">
    <div id="formC">
        <form name="contactForm" onsubmit="return validateForm()" action="validate_staff_registration.php" method="POST">
            <div class="imgcontainer">
                <img src="img/defualt.png" alt="Avatar" class="avatar">
            </div>
            <div class="row">
                <label>ID Number</label>
                <input type="text" name="id_number" placeholder="01234567890123">
                <div class="error" id="idErr"></div>
            </div>
            <div class="row">
                <label>Authorization</label>
                <input type="text" name="auth" placeholder="FullAccess or Restricted">
                <div class="error" id="authErr"></div>
            </div>
            <div class="row">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</div>
<?php include "footer.php" ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script>
    $(window).load(function() {
        const loader_div = document.querySelector(".loader");
        loader_div.className += " hidden";
    });
</script>
</body>
</html>



