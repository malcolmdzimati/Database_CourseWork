<?php
    require_once("config.php");
    $db=Database_Connection::getInstance();
    session_start();

    function generateEmpID(){
        $string="ABCDEFGHIJKLMNOPQRSTUVWXYY0123456789";
        $EmpID="";

        for ($i=0;$i<6;$i++)
            $EmpID=$EmpID . $string[rand(0,strlen($string)-1)];
        return $EmpID;
    }

    function checkDuplicate($c){
        $EmpID=generateEmpID();
        $query="SELECT Emp_Id FROM Electoral_Staff WHERE Emp_Id = '$EmpID'";
        $result=$c->query($query);

        if ($result->num_rows>0)
            checkDuplicate($c);
        else
            return $EmpID;
    }

    if ($_SERVER["REQUEST_METHOD"]=="POST") {
        $id_number=$_POST["id_number"];
        $isAuthorized=$_POST["auth"];

        $query="SELECT National_Id FROM Electoral_Staff WHERE National_Id = '$id_number'";
        $conn=$db->getConnection();
        $result=$db->getConnection()->query($query);

        if ($result->num_rows>0)
            header('location: index.php');
        else{
            $query="SELECT National_Id FROM Person WHERE National_Id = '$id_number'";
            $result=$conn->query($query);

            if ($result->num_rows<=0)
                header('register_voter.php');

            $EmpID=checkDuplicate($db->getConnection());

            $stmt=$conn->prepare("INSERT INTO Electoral_Staff VALUES (?,?,?)");

            $zero = 0;
            $one = 1;

            if ($isAuthorized == "FullAccess")
                $stmt->bind_param("ssi",$EmpID,$id_number,$one);
            else
                $stmt->bind_param("ssi",$EmpID,$id_number,$zero);

            $result=$stmt->execute();

            if ($result) {
                $_SESSION["emp_id"] = $EmpID;
                $_SESSION["staffloggedin"] = true;
                header("location: staff_login.php");
            }
            else
                header('location: register_staff.php');
        }
    }
?>