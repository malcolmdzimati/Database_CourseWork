<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome Page</title>
        <link rel="stylesheet" href="css/full_access_style.css?v=<?php echo time(); ?>">
        <link rel="stylesheet" href="css/footer.css?=<?php echo time(); ?>">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">
        <script src="js/trending.js"></script>
    </head>
    <body>
        <div class="loader"><img src="img/loader.gif" alt="Sharingan"></div>
        <?php include "header.php" ?>
        <div class="container">
            <!-- Voter  -->
            <a href="register_voter.php">
                <div class="picture_box">
                    <div class="image">
                        <img src="img/voter.png" alt="CyberPunk 2077">
                    </div>
                    <span></span> <span></span> <span></span> <span></span>
                    <div class="content">
                        <br><br><br>
                        REGISTER VOTERS
                    </div>
                </div>
            </a>
            <!--Staff-->
            <a href="register_staff.php">
                <div class="picture_box">
                    <div class="image">
                        <img src="img/staff.png" alt="Staff"">
                    </div>
                    <span></span> <span></span> <span></span> <span></span>
                    <div class="content">
                        <br><br><br>
                         REGISTER STAFF
                    </div>
                </div>
            </a>
        </div>
        <?php include "footer.php"; ?>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
        <script>
            $(window).load(function() {
                const loader_div = document.querySelector(".loader");
                loader_div.className += " hidden";
            });
        </script>
    </body>
</html>

