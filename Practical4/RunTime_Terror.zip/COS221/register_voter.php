<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/register_voter_style.css?=<?php echo time(); ?>">
        <link rel="stylesheet" href="css/footer.css?=<?php echo time(); ?>">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">
        <script src="js/voter_reg_validation.js"></script>
    </head>
    <body>
        <div class="loader"><img src="img/loader.gif" alt="Sharingan"></div>
        <?php include "header.php"; ?>
        <div class="wrapper" style="background-color: black; padding-bottom: 100px; padding-top: 100px;">
            <div id="formC">
                <form name="contactForm" onsubmit="return validateForm()" action="validate_voter_registration.php" method="POST">
                    <div class="imgcontainer">
                        <img src="img/defualt.png" alt="Avatar" class="avatar">
                    </div>
                    <div class="row">
                        <label>ID Number</label>
                        <input type="text" name="id_number" placeholder="01234567890123">
                        <div class="error" id="idErr"></div>
                    </div>
                    <div class="row">
                        <label>Surname</label>
                        <input type="text" name="surname" placeholder="Deer">
                        <div class="error" id="surnameErr"></div>
                    </div>
                    <div class="row">
                        <label>Name</label>
                        <input type="text" name="name" placeholder="John">
                        <div class="error" id="nameErr"></div>
                    </div>
                    <div class="row">
                        <label>Initials</label>
                        <input type="text" name="initials" placeholder="JD">
                        <div class="error" id="initErr"></div>
                    </div>
                    <div class="row">
                        <label>Birth Date</label><br>
                        <input type="date" name="birth_date" class="date" value="2021-01-01" min="1910-01-01" max="2003-04-30">
                        <div class="error" id="birthDateErr"></div>
                    </div>
                    <br>
                    <div class="row">
                        <label>Sex</label>
                        <input type="text" name="sex" placeholder="F or M">
                        <div class="error" id="sexErr"></div>
                    </div>
                    <div class="row">
                        <label>House Number</label>
                        <input type="text" name="house_nr" placeholder="33 Gemin Villas">
                        <div class="error" id="houseNrErr"></div>
                    </div>
                    <div class="row">
                        <label>Street</label>
                        <input type="text" name="street" placeholder="Prinsberg Street">
                        <div class="error" id="streetErr"></div>
                    </div>
                    <div class="row">
                        <label>Suburb</label>
                        <input type="text" name="suburb" placeholder="Ben Fleur">
                        <div class="error" id="suburbErr"></div>
                    </div>
                    <div class="row">
                        <label>Ward Number</label>
                        <input type="text" name="ward_num" placeholder="CJHB748">
                        <div class="error" id="wardNumErr"></div>
                    </div>
                    <div class="row">
                        <label>City</label>
                        <input type="text" name="city" placeholder="Pretoria">
                        <div class="error" id="cityErr"></div>
                    </div>
                    <div class="row">
                        <label>Province</label>
                        <input type="text" name="province" placeholder="Mpumalanga">
                        <div class="error" id="provinceErr"></div>
                    </div>
                    <div class="row">
                        <input type="submit" value="Submit">
                    </div>
                </form>
            </div>
        </div>
        <?php include "footer.php" ?>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
        <script>
            $(window).load(function() {
                const loader_div = document.querySelector(".loader");
                loader_div.className += " hidden";
            });
        </script>
    </body>
</html>



