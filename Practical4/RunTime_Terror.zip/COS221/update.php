<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/voter_login.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/footer.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">
    <script src="js/update_validation.js"></script>
</head>
<body>
<div class="loader"><img src="img/loader.gif" alt="Sharingan"></div>
<?php include "voter_header.php"; ?>
<div class="wrapper" style="background-color: black; padding-bottom: 100px; padding-top: 100px;">
    <div id="formC">
        <form name="contactForm" onsubmit="return validateForm()" action="validate_update.php" method="POST">
            <div class="imgcontainer">
                <img src="img/defualt.png" alt="Avatar" class="avatar">
            </div>
            <br>
            <div class="row">
                <label>House Number</label>
                <input type="text" name="house_nr" placeholder="33 Gemin Villas">
                <div class="error" id="houseNrErr"></div>
            </div>
            <div class="row">
                <label>Street</label>
                <input type="text" name="street" placeholder="Prinsberg Street">
                <div class="error" id="streetErr"></div>
            </div>
            <div class="row">
                <label>Suburb</label>
                <input type="text" name="suburb" placeholder="Ben Fleur">
                <div class="error" id="suburbErr"></div>
            </div>
            <div class="row">
                <label>Ward Number</label>
                <input type="text" name="ward_num" placeholder="CJHB748">
                <div class="error" id="wardNumErr"></div>
            </div>
            <div class="row">
                <label>City</label>
                <input type="text" name="city" placeholder="Pretoria">
                <div class="error" id="cityErr"></div>
            </div>
            <div class="row">
                <label>Province</label>
                <input type="text" name="province" placeholder="Mpumalanga">
                <div class="error" id="provinceErr"></div>
            </div>
            <div class="row">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</div>
<?php include "footer.php" ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script>
    $(window).load(function() {
        const loader_div = document.querySelector(".loader");
        loader_div.className += " hidden";
    });
</script>
</body>
</html>



