<div class="footer" style="text-align: center">
    <div class="footer-content">
        <div class="footer-section about">
            <h1 class="logo-text"><span>RunTime</span>Terror</h1>
            <p style="font-size: 12px">
                Your Voice, Your Choice. <br>
                Voting is the representation of our commitment to ourselves, each other, this nation and this world.
            </p>
            <div class="contact">
                <span><i class="fas fa-phone"></i> &nbsp; +27(0) 23-456-7890</span>
                <span><i class="fas fa-envelope"></i> &nbsp; info@rtt.com</span>
            </div>
            <div class="socials">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">&copy; rtt.com | Designed by RunTime Developers</div>
</div>