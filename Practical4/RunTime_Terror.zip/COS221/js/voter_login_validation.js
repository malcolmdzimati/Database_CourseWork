function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

function validateForm() {
    var idNum = (document.contactForm.id_number.value).trim();
    var password = (document.contactForm.password.value).trim();
    var idErr = passwordErr = true;

    if(idNum === "") {
        printError("idErr", "Please enter your ID number");
    } else if (idNum.length !== 13) {
        printError("idErr", "Please enter a valid ID number");
    }
    else {
        if(/^[0-9]+$/.test(idNum) === false)
            printError("idErr", "Please enter a valid ID number");
        else {
            printError("idErr", "");
            idErr = false;
        }
    }

    if(password === "")
        printError("passwordErr", "Please enter your password");
    else {
        if(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,}$/.test(password) === false)
            printError("passwordErr", "Please enter a valid password");
        else{
            printError("passwordErr", "");
            passwordErr = false;
        }
    }

    return (idErr || passwordErr) !== true;
}