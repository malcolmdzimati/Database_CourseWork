function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

function validateForm() {
    var idNum = (document.contactForm.id_number.value).trim();
    var auth = (document.contactForm.auth.value).trim();
    var idErr = authErr = true;

    if(idNum === "") {
        printError("idErr", "Please enter your ID number");
    } else if (idNum.length !== 13) {
        printError("idErr", "Please enter a valid ID number");
    }
    else {
        if(/^[0-9]+$/.test(idNum) === false)
            printError("idErr", "Please enter a valid ID number");
        else {
            printError("idErr", "");
            idErr = false;
        }
    }

    if(auth == "")
        printError("authErr", "Please enter type of authorization");
    else if(auth != "FullAccess" && auth != "Restricted")
        printError("authErr", "Please enter a valid authorization (FullAccess or Restricted)");
    else{
        printError("authErr", "");
        authErr = false;
    }

    return (idErr || authErr) !== true;
}