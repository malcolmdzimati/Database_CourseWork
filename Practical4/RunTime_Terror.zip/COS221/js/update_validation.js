function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

function validateForm() {
    var house_nr = (document.contactForm.house_nr.value).trim();
    var ward = (document.contactForm.ward_num.value).trim();
    var street = (document.contactForm.street.value).trim();
    var suburb = (document.contactForm.suburb.value).trim();
    var city = (document.contactForm.city.value).trim();
    var province = (document.contactForm.province.value).trim();

    var houseNrErr = streetErr = suburbErr = wardNumErr = cityErr =  provinceErr = true;

    if(house_nr == "")
        printError("houseNrErr", "Please enter your house number");
    else if(/^[a-zA-Z0-9\s]+$/.test(house_nr) === false)
        printError("houseNrErr", "Please enter a valid house number");
    else {
        printError("houseNrErr", "");
        houseNrErr = false;
    }

    if(street == "")
        printError("streetErr", "Please enter your street");
    else if(/^[a-zA-Z\s]+$/.test(street) === false)
        printError("streetErr", "Please enter a valid street");
    else {
        printError("streetErr", "");
        streetErr = false;
    }

    if(suburb == "")
        printError("suburbErr", "Please enter your suburb");
    else  if(/^[a-zA-Z\s]+$/.test(suburb) === false)
        printError("suburbErr", "Please enter a valid suburb");
    else {
        printError("suburbErr", "");
        suburbErr = false;
    }

    var wards = ['CJHB73', 'EMH11', 'EMH23', 'GSD1', 'CJHB76', 'CJHB32', 'CPT4', 'CPT5', 'CJHB75', 'CJHB74', 'CPT45', 'GSD10', 'GSD6', 'NKG12'];

    if(ward == "")
        printError("wardNumberErr", "Please enter ward number");
    else if (ward.length < 4 || ward.length > 8)
        printError("wardNumberErr", "Please enter a valid ward number");
    else  if(wards.includes(ward) === false)
        printError("wardNumberErr", "Please enter a valid ward number");
    else {
        printError("wardNumberErr", "");
        wardNumErr = false;
    }

    if(city == "")
        printError("cityErr", "Please enter your city");
    else  if(/^[a-zA-Z\s]+$/.test(suburb) === false)
        printError("cityErr", "Please enter a valid city");
    else {
        printError("cityErr", "");
        cityErr = false;
    }

    var rt_provinces = ["Western Cape", "Gauteng", "Mpumalanga"];
    if(province == "")
        printError("provinceErr", "Please enter your province");
    else if(rt_provinces.includes(province) === false)
        printError("provinceErr", "Please enter a valid province");
    else {
        printError("provinceErr", "");
        provinceErr = false;
    }

    return (houseNrErr || streetErr || wardNumErr || suburbErr || cityErr || provinceErr) != true;
}