function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

function validateForm() {
    var empNum = (document.contactForm.emp_number.value).trim();
    var password = (document.contactForm.password.value).trim();
    var empErr = passwordErr = true;

    if(empNum == "") {
        printError("empErr", "Please enter your Employee ID ");
    } else if (empNum.length !== 6) {
        printError("empErr", "Please enter a valid Employee ID");
    }
    else {
        if(/^[A-Z0-9]+$/.test(empNum) === false)
            printError("empErr", "Please enter a valid Employee ID");
        else {
            printError("empErr", "");
            empErr = false;
        }
    }

    if(password == "")
        printError("passwordErr", "Please enter your password");
    else {
        if(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,}$/.test(password) === false)
            printError("passwordErr", "Please enter a valid password");
        else{
            printError("passwordErr", "");
            passwordErr = false;
        }
    }

    return (empErr || passwordErr) != true;
}