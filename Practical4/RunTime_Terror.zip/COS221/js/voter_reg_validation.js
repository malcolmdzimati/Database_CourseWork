function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

function validateForm() {
    var idNum = (document.contactForm.id_number.value).trim();
    var surname = (document.contactForm.surname.value).trim();
    var name = (document.contactForm.name.value).trim();
    var initials = (document.contactForm.initials.value).trim();
    var sex = (document.contactForm.sex.value).trim();
    var house_nr = (document.contactForm.house_nr.value).trim();
    var ward = (document.contactForm.ward_num.value).trim();
    var street = (document.contactForm.street.value).trim();
    var suburb = (document.contactForm.suburb.value).trim();
    var city = (document.contactForm.city.value).trim();
    var province = (document.contactForm.province.value).trim();

    var idErr = surnameErr = nameErr = initErr = sexErr = houseNrErr = streetErr = suburbErr = wardNumErr = cityErr =  provinceErr = passwordErr = true;

    if(idNum == "")
        printError("idErr", "Please enter your ID number");
    else if (idNum.length !== 13)
        printError("idErr", "Please enter a valid ID number");
    else {
        if(/^[0-9]+$/.test(idNum) === false)
            printError("idErr", "Please enter a valid ID number");
        else {
            printError("idErr", "");
            idErr = false;
        }
    }

    if(surname == "")
        printError("surnameErr", "Please enter your surname");
    else {
        if(/^[a-zA-Z\s]+$/.test(surname) === false)
            printError("surnameErr", "Please enter a valid surname");
        else {
            printError("surnameErr", "");
            surnameErr = false;
        }
    }

    if(name == "")
        printError("nameErr", "Please enter your name");
    else {
        if(/^[a-zA-Z\s]+$/.test(name.trim()) === false)
            printError("nameErr", "Please enter a valid name");
        else {
            printError("nameErr", "");
            nameErr = false;
        }
    }

    if(initials == "")
        printError("initErr", "Please enter your initials");
    else {
        if(/^[a-zA-Z\s]+$/.test(initials) === false)
            printError("initErr", "Please enter valid initials");
        else {
            printError("initErr", "");
            initErr = false;
        }
    }

    if(sex == "")
        printError("sexErr", "Please enter your sex");
    else if (sex != "F" && sex != "M")
        printError("sexErr", "Please enter either M or F");
    else if (sex == "F" || sex == "M"){
        printError("sexErr", "");
        sexErr = false;
    }

    if(house_nr == "")
        printError("houseNrErr", "Please enter your house number");
    else if(/^[a-zA-Z0-9\s]+$/.test(house_nr) === false)
        printError("houseNrErr", "Please enter a valid house number");
    else {
        printError("houseNrErr", "");
        houseNrErr = false;
    }

    if(street == "")
        printError("streetErr", "Please enter your street");
    else if(/^[a-zA-Z\s]+$/.test(street) === false)
        printError("streetErr", "Please enter a valid street");
    else {
        printError("streetErr", "");
        streetErr = false;
    }

    if(suburb == "")
        printError("suburbErr", "Please enter your suburb");
    else  if(/^[a-zA-Z\s]+$/.test(suburb) === false)
        printError("suburbErr", "Please enter a valid suburb");
    else {
        printError("suburbErr", "");
        suburbErr = false;
    }

    var wards = ['CJHB73', 'EMH11', 'EMH23', 'GSD1', 'CJHB76', 'CJHB32', 'CPT4', 'CPT5', 'CJHB75', 'CJHB74', 'CPT45', 'GSD10', 'GSD6', 'NKG12'];

    if(ward == "")
        printError("wardNumberErr", "Please enter ward number");
    else if (ward.length < 4 || ward.length > 8)
        printError("wardNumberErr", "Please enter a valid ward number");
    else  if(/^[A-Z0-9\s]+$/.test(ward) === false)
        printError("wardNumberErr", "Please enter a valid ward number");
    else {
        printError("wardNumberErr", "");
        wardNumErr = false;
    }

    if(city == "")
        printError("cityErr", "Please enter your city");
    else  if(/^[a-zA-Z\s]+$/.test(suburb) === false)
        printError("cityErr", "Please enter a valid city");
    else {
        printError("cityErr", "");
        cityErr = false;
    }

    var rt_provinces = ["Western Cape", "Gauteng", "Mpumalanga"];
    if(province == "")
        printError("provinceErr", "Please enter your province");
    else if(rt_provinces.includes(province) === false)
        printError("provinceErr", "Please enter a valid province");
    else {
        printError("provinceErr", "");
        provinceErr = false;
    }

    return (idErr || surnameErr || nameErr || initErr || sexErr || houseNrErr || streetErr || wardNumErr || suburbErr || cityErr || provinceErr) !== true;
}