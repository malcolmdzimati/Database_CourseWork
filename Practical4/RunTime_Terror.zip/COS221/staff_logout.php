<?php
    session_start();
    session_destroy();
    unset($_SESSION["emp_id"]);
    unset($_SESSION["staffloggedin"]);

    header("location: index.php");

?>