<?php
    require_once("config.php");
    $db = Database_Connection::getInstance();
    session_start();

    $id=$_POST["emp_number"];
    $password=$_POST["password"];

    if ($_SERVER["REQUEST_METHOD"]=="POST"){
        $sql="SELECT Person.National_Id, Last_Name, Authorized, Initials, UPassword FROM Electoral_Staff INNER JOIN Person ON Electoral_Staff.National_Id=Person.National_Id WHERE Emp_Id='$id' ";
        $result=$db->getConnection()->query($sql);

        if ($result->num_rows>0) {
            while ($row=$result->fetch_assoc()) {
                if (password_verify($password,$row["UPassword"])) {
                    $_SESSION["User"]=$row["Last_Name"]. ", ". "Initials";
                    $_SESSION["loggedInStaff"]=true;

                    if ($row["Authorized"] == 1)
                        header("location: full_access.php");

                    else {
                        $_SESSION["fullAccess"] = false;
                        header('location: register_voter.php');
                    }
                }
                else
                    header('location: staff_login.php');
            }
        }
    } 
    else
        header('location: staff_login.php');
?>