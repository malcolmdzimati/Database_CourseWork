<?php
    require_once("config.php");
    $db = Database_Connection::getInstance();
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $id_number= $_SESSION["id"];
        $address=$_POST["house_nr"] . ", " . $_POST["street"] . ", " . $_POST["suburb"] . ", " . $_POST["city"] . ", " . $_POST["province"];
        $wardNum = $_POST["ward_num"];

        $sql="UPDATE Person SET Address='$address', Ward_Num='$wardNum' WHERE National_Id= '$id_number'";
        $result=$db->getConnection()->query($sql);

        if (mysqli_query($db->getConnection() ,$sql))
            header("location: voter_login.php");
        else
            echo "Error";
    }
?>