<?php
    require_once("config.php");
    $db = Database_Connection::getInstance();
    session_start();

    if ($_SERVER["REQUEST_METHOD"]=="POST"){
        $id_number=$_POST["id_number"];
        $password=$_POST["password"];

        $sql="SELECT National_Id, Last_Name, Initials, has_Voted, UPassword FROM Person WHERE National_Id = '$id_number'";
        $result=$db->getConnection()->query($sql);

        if ($result->num_rows>0) {
            while ($row=$result->fetch_assoc()) {
                if (password_verify($password,$row["UPassword"])) {
                    $_SESSION["User"]=$row["Initials"] . " " . $row["Last_Name"];
                    $_SESSION["loggedIn"]=true;
                    $_SESSION["id"] = $row["National_Id"];
                 
                    if ($row["has_Voted"]==1)
                        $_SESSION["voted"]=true;
                    else
                        $_SESSION["voted"]=false;

                    header('location: ballot_page.php');
                }
                else
                    header('location: voter_login.php');
            }
        }
        else
            header("location: staff_login.php");
    }
?>