<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/voter_login.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/footer.css?=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Candal|Lora" rel="stylesheet">
    <script src="js/voter_login_validation.js"></script>
</head>
<body>
    <div class="loader"><img src="img/loader.gif" alt="Sharingan"></div>
    <?php include "voter_header.php"; ?>
    <?php
    if (isset($_SESSION["password"]) && $_SESSION["loggedin"] === true)
        echo "Here is your password: {$_SESSION["password"]}";
    ?>
    <div class="wrapper" style="background-color: black; padding-bottom: 100px; padding-top: 100px;">
        <div id="formC">
            <form name="contactForm" onsubmit="return validateForm()" action="validate_voter_login.php" method="POST">
                <div class="imgcontainer">
                    <img src="img/defualt.png" alt="Avatar" class="avatar">
                </div>
                <div class="row">
                    <label>ID Number</label>
                    <input type="text" name="id_number">
                    <div class="error" id="idErr"></div>
                </div>
                <div class="row">
                    <label>Password</label>
                    <input type="password" name="password">
                    <div class="error" id="passwordErr"></div>
                </div>
                <div class="row">
                    <input type="submit" value="Submit">
                </div>
            </form>
        </div>
    </div>
    <?php include "footer.php" ?>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
    <script>
        $(window).load(function() {
            const loader_div = document.querySelector(".loader");
            loader_div.className += " hidden";
        });
    </script>
</body>
</html>
