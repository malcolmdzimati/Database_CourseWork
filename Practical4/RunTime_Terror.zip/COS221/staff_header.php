<div class="header" style="background-color: white">
    <img src="img/logo.png" width="200" height="200px" alt="Logo">
    <nav class="nav_style" >
        <a href="index.php" class="nav_buttons"><i></i>Home</a>
        <a href="trending.html" class="nav_buttons"><i></i>Candidates</a>
        <a href="trending.html" class="nav_buttons"><i></i>Municipalities</a>
        <a href="new_releases.html" class="nav_buttons"><i></i>Results</a>
        <a href="top_rated.html" class="nav_buttons"><i></i>How To</a>
        <a href="featured.html" class="nav_buttons"><i></i>About</a>
        <?php
            session_start();
            if (isset($_SESSION["emp_id"]) && $_SESSION["staffloggedin"] == true)
                echo '<a href="staff_logout.php" class="nav_buttons"><i></i>Logout</a>';
        ?>
    </nav>
</div>

